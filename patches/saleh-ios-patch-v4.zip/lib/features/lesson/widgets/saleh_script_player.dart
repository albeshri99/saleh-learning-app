import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/design/app_typography.dart';
import '../../../core/design/widgets/app_card.dart';
import '../../../domain/models/child_profile.dart';
import '../../../domain/models/saleh_script.dart';
import '../../../domain/models/timeline_event.dart';
import '../../../services/audio/audio_service.dart';

/// مشغّل سكربت صالح — قلب نظام التزامن.
///
/// يعرض جمل صالح واحدة تلو الأخرى في فقاعة كلام، يشغّل صوت كل جملة
/// (إن وجد)، ويطلق أحداث الخط الزمني [TimelineEvent] في توقيتها
/// ليتفاعل معها المشهد (إظهار حرف، نبض، رسم مسار...).
class SalehScriptPlayer extends ConsumerStatefulWidget {
  const SalehScriptPlayer({
    super.key,
    required this.lines,
    required this.profile,
    this.tailDirection = SpeechTailDirection.down,
    this.onEvent,
    this.onFinished,
    this.compact = false,
    this.onNarratingChanged,
  });

  final List<SalehLine> lines;
  final ChildProfile profile;

  /// اتجاه ذيل الفقاعة نحو صالح (يختلف بين تخطيط الهاتف والشاشات الواسعة).
  final SpeechTailDirection tailDirection;
  final void Function(TimelineEvent event)? onEvent;
  final VoidCallback? onFinished;
  final bool compact;
  final ValueChanged<bool>? onNarratingChanged;

  @override
  ConsumerState<SalehScriptPlayer> createState() => _SalehScriptPlayerState();
}

class _SalehScriptPlayerState extends ConsumerState<SalehScriptPlayer> {
  int _lineIndex = -1;
  final List<Timer> _timers = [];
  bool _finished = false;
  late final AudioService _audio;

  @override
  void initState() {
    super.initState();
    _audio = ref.read(audioServiceProvider);
    WidgetsBinding.instance.addPostFrameCallback((_) => _playLine(0));
  }

  @override
  void dispose() {
    for (final t in _timers) {
      t.cancel();
    }
    unawaited(_audio.stop());
    widget.onNarratingChanged?.call(false);
    super.dispose();
  }

  void _playLine(int index) {
    if (!mounted) return;
    if (index >= widget.lines.length) {
      widget.onNarratingChanged?.call(false);
      setState(() => _finished = true);
      widget.onFinished?.call();
      return;
    }
    setState(() => _lineIndex = index);
    widget.onNarratingChanged?.call(true);

    // حالة talking لا تُدار من هنا: تشغيل الصوت عبر AudioService هو ما
    // يقودها (انظر SalehCharacterController) — لا مؤقتات ثابتة للكلام.
    final line = widget.lines[index];
    if (line.audio != null) {
      unawaited(_audio.play(line.audio!));
    } else {
      // لا نسمح لصوت سطر سابق أطول من مدته التقديرية أن يمتد إلى السطر
      // التالي؛ كما تُطفأ حركة الفم فورًا مع الإيقاف الفعلي.
      unawaited(_audio.stop());
    }
    for (final event in line.events) {
      _timers.add(Timer(event.at, () {
        if (mounted) widget.onEvent?.call(event);
      }));
    }
    _timers.add(Timer(line.duration, () => _playLine(index + 1)));
  }

  @override
  Widget build(BuildContext context) {
    if (_lineIndex < 0 || widget.lines.isEmpty) {
      return const SizedBox.shrink();
    }
    final line = widget.lines[_lineIndex.clamp(0, widget.lines.length - 1)];
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 250),
      child: SpeechBubble(
        key: ValueKey(_finished ? 'done_$_lineIndex' : _lineIndex),
        tail: widget.tailDirection,
        compact: widget.compact,
        child: Text(
          line.resolve(widget.profile),
          maxLines: widget.compact ? 3 : null,
          overflow: widget.compact ? TextOverflow.ellipsis : null,
          style: AppTypography.speech.copyWith(
            fontSize: widget.compact ? 13.5 : null,
            height: widget.compact ? 1.18 : null,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
